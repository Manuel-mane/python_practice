from setuptools import setup
import setuptools

setup(name='dsnd_distributions_manu95',
      version='0.1',
      description='Gaussian distributions',
      packages=setuptools.find_packages(), 
      author="Manuel Mane",
      author_email='manito920514@gmail.com',
      zip_safe=False)
