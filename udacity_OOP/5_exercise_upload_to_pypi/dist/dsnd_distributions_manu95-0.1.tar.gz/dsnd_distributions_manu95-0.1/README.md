# Udacity OOP

This package is part of the Udacity Machine Learning Foundation course. 
In this package we describe the Binomial and Gaussian distributions. 